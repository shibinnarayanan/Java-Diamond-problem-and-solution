package com.svv.diamondproblem.solution;

interface A {
	public void greet();
	
	default public void method()
	{
		System.out.println("Hi");
	}
}

interface B {
	public void greet();
	
	default public void method()
	{
		System.out.println("Hellow");
	}
}

public class C implements A,B
{

	@Override
	public void greet() {
		System.out.println("Good after noon");
	}

	@Override
	public void method() {
		// TODO Auto-generated method stub
		A.super.method();
	}


}
