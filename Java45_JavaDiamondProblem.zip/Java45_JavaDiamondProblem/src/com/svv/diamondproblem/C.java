package com.svv.diamondproblem;

class A {
	public void greet() {
		System.out.println("Good morning");
	}
}

class B {
	public void greet() {
		System.out.println("Good night");
	}
}
//Multiple inheritance with classes not possible in java
public class C extends A,B
{

	public static void main(String[] args) {
		
	}

}
